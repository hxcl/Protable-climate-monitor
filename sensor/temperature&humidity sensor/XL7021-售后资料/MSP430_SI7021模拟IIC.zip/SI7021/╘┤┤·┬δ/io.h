#ifndef IO_H
#define IO_H

    /*
    **LED-ָʾ��
    */
    #define   LEDR_B     BIT0       //P1.0��ɫLED1
    #define   LEDG_B     BIT6       //P1.6��ɫLED2
  
    #define   LED_DIR     P1DIR       //P1.0
    #define   LED_OUT     P1OUT       //P1.6

    #define   LEDR_OFF    LED_OUT &=~LEDR_B
    #define   LEDR_ON     LED_OUT |= LEDR_B

    #define   LEDG_OFF    LED_OUT &=~LEDG_B
    #define   LEDG_ON     LED_OUT |= LEDG_B

    /*
    **SI7021��ʪ�ȴ�����
    * ��IO��ģ��IIC
    */
    //P1.4 DATA
    //P1.5 SCLK
    #define   SI7021_SDA_B     BIT4       //P1.4-IIC-DATA
    #define   SI7021_CLK_B     BIT5       //P1.5-IIC-SCLK
  
    #define   SI7021_DIR       P1DIR       
    #define   SI7021_OUT       P1OUT   
    #define   SI7021_IN        P1IN 
    #define   SI7021_REN       P1REN

    #define   SI7021_Power_ON   SI7021_OUT |= SI7021_Power_B 
    #define   SI7021_Power_OFF  SI7021_OUT &=~SI7021_Power_B

    #define   SI7021_CLK_H     SI7021_OUT |= SI7021_CLK_B
    #define   SI7021_CLK_L     SI7021_OUT &=~SI7021_CLK_B

    #define   SI7021_SDA_H     SI7021_OUT |= SI7021_SDA_B
    #define   SI7021_SDA_L     SI7021_OUT &=~SI7021_SDA_B
    #define   SI7021_Data      SI7021_IN  &  SI7021_SDA_B
    #define   SI7021_SDA_IN    SI7021_DIR &=~SI7021_SDA_B;SI7021_SDA_H;P1REN|= SI7021_SDA_B
    #define   SI7021_SDA_OUT   SI7021_DIR |= SI7021_SDA_B;P1REN&=~SI7021_SDA_B

#endif 