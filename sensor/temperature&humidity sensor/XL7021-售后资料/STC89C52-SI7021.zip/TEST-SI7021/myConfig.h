

#ifndef	__myConfig_H
#define	__myConfig_H


#include "myType.h"

#include "lcd.h"

#include "./MCU/MCU-STC11L04.h"
#include "./HARDWARE/SI7021/SI7021.h"






#endif//ifndef	__myConfig_H

